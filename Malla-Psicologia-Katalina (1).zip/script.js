
const ramos = [
    { id: 'ramo1', nombre: 'Introducción a la Psicología', semestre: 1, prereq: [] },
    { id: 'ramo2', nombre: 'Procesos Psicológicos', semestre: 1, prereq: [] },
    { id: 'ramo3', nombre: 'Fundamentos Biológicos de la Psicología', semestre: 1, prereq: [] },
    { id: 'ramo4', nombre: 'Introducción al Análisis de Datos', semestre: 1, prereq: [] },
    { id: 'ramo5', nombre: 'Fundamentos Científicos de la Psicología', semestre: 2, prereq: ['ramo1'] },
    { id: 'ramo6', nombre: 'Teorías Sociales', semestre: 2, prereq: ['ramo2'] },
    { id: 'ramo7', nombre: 'Epistemología para Psicología', semestre: 2, prereq: ['ramo1'] },
    { id: 'ramo8', nombre: 'Habilidades Profesionales I', semestre: 2, prereq: [] },
    // Puedes seguir completando la malla aquí...
];

function crearMalla() {
    const container = document.getElementById('malla-container');
    container.innerHTML = '';

    ramos.forEach(ramo => {
        const card = document.createElement('div');
        card.classList.add('card');
        card.id = ramo.id;
        card.innerText = ramo.nombre;
        card.onclick = () => toggleAprobado(ramo.id);

        const estado = localStorage.getItem(ramo.id);
        if (estado === 'aprobado') card.classList.add('aprobado');
        else if (estado === 'disponible') card.classList.add('disponible');
        else card.classList.add('bloqueado');

        container.appendChild(card);
    });

    actualizarDisponibilidad();
    actualizarProgreso();
}

function toggleAprobado(id) {
    const card = document.getElementById(id);
    if (card.classList.contains('aprobado')) {
        card.classList.remove('aprobado');
        localStorage.setItem(id, 'bloqueado');
    } else {
        card.classList.add('aprobado');
        localStorage.setItem(id, 'aprobado');
    }
    actualizarDisponibilidad();
    actualizarProgreso();
}

function actualizarDisponibilidad() {
    ramos.forEach(ramo => {
        const card = document.getElementById(ramo.id);
        if (!card.classList.contains('aprobado')) {
            const cumplidos = ramo.prereq.every(pr => localStorage.getItem(pr) === 'aprobado');
            card.classList.remove('bloqueado', 'disponible');
            card.classList.add(cumplidos ? 'disponible' : 'bloqueado');
            localStorage.setItem(ramo.id, cumplidos ? 'disponible' : 'bloqueado');
        }
    });
}

function actualizarProgreso() {
    const total = ramos.length;
    const completados = ramos.filter(r => localStorage.getItem(r.id) === 'aprobado').length;
    const porcentaje = Math.round((completados / total) * 100);
    document.getElementById('progress-bar').style.width = porcentaje + '%';
    document.getElementById('progress-text').innerText = `${porcentaje}% completado`;
}

function resetMalla() {
    ramos.forEach(r => localStorage.removeItem(r.id));
    crearMalla();
}

document.addEventListener('DOMContentLoaded', crearMalla);
